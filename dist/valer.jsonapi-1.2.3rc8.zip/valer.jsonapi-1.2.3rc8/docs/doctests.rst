Doctests
========

.. include:: ../src/senaite/jsonapi/tests/doctests/auth.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/version.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/users.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/catalogs.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/search.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/create.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/read.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/update.rst
.. include:: ../src/senaite/jsonapi/tests/doctests/push.rst
